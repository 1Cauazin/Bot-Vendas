# Sistema de vendas

Sistema de vendas via discord, o sistema é um projeto antigo meu, mas todas as funções estão em perfeitos estado e funcionando, algumas API's utilizadas podem ter sido atulizadas.
